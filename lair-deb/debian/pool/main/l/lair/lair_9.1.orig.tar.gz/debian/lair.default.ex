# Defaults for lair initscript
# sourced by /etc/init.d/lair
# installed at /etc/default/lair by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
