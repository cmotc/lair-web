?package(lair):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="lair" command="/usr/bin/lair"
