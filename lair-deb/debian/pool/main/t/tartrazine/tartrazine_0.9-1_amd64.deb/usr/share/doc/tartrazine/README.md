# tartrazine
robot poison. Actually just a specialized tox groupbot written in vala.

Tartrazine(Named thus because of an obscure Futurama reference) is a Tox bot
with a sort of peculiar goal. It's being written for integration into other
kinds of projects, especially games, and is intended to be modular and fully
scriptable. For now, I'm only going to implement the parts I need. It's supposed
to do the leg-work of setting up a tox client, then provide a familiar or usable
interface for the rest of the program to use.

References
----------
[A similar idea was suggested for the GSoC](https://wiki.tox.chat/developers/gsoc/2015/ideas)
[Tox VAPI Project](https://github.com/ricinapp/tox-vapi)
[Ratox](http://ratox.2f30.org/)
